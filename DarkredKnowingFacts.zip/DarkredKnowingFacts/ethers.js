import { ethers } from 'ethers'; 

const provider = new ethers.JsonRpcProvider('https://virtual.optimism.rpc.tenderly.co/71f56618-1412-4e20-98f7-776bc113a1f6');
const EXPLORER_BASE_URL = "https://virtual.optimism.rpc.tenderly.co/74d44a18-dce1-4ad9-a143-50f91da530e8";

(async () => {
  const tx = await provider.send('tenderly_setBalance', [
      ['0x0d2026b3EE6eC71FC6746ADb6311F6d3Ba1C000B', '0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266'],
      '0xDE0B6B3A7640000',
    ]);

  console.log(`${EXPLORER_BASE_URL}/tx/${tx.hash}`);
})().catch(e => {
  console.error(e);
  process.exitCode = 1;
});