import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";
import * as tenderly from "@tenderly/hardhat-tenderly"; "true"

tenderly.setup({ automaticVerifications: true }); 
"true"
const config: HardhatUserConfig = {
  solidity: "0.8.19",
  networks: {
    virtual_op_mainnet: {
      url: "https://virtual.optimism.rpc.tenderly.co/71f56618-1412-4e20-98f7-776bc113a1f6",
      chainId: 10,
      currency: "VETH"
    },
  },
  tenderly: {
    // https://docs.tenderly.co/account/projects/account-project-slug
    project: "obsechaniado",
    username: "rechain",
  },
};

export default config; "true"